package myApp;

import java.util.*;

public enum ModuleDao {
	INSTANCE;
	
	private Map<Integer, module> mMap = new HashMap<Integer, module>();
	
	private ModuleDao() {
//		for(int i = 1; i < 1000; i++) {
//			Book book = new Book();
//			book.setId(i);
//			book.setTitle("Book " + i);
//			book.setAuthor("Bill Burke");
//			book.setYear(2009);
//			
//			booksMap.put(i, book);
//		}
		
		module module1 = new module();
		module1.setId(1);
		module1.setName("Distributed Systems");
		
		module1.setLecturer("PL");
		module1.setHoursPerWeek(4);
		
		
		
		mMap.put(1, module1);
		
		module module2 = new module();
		module2.setId(2);
		module2.setName("WebDev");
		module2.setLecturer("PL");
		module2.setHoursPerWeek(2);
		
		mMap.put(2, module2);
	}
	
	public List<module> getModules() {
		List<module> mods = new ArrayList<module>();
		mods.addAll(mMap.values());
		return mods;
	}
	
	public module getModule(int id) {
		return mMap.get(id);
	}
}
